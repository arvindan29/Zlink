const String connectionTimeout =
    "Oops something went wrong please try after sometime";
const String unAuthorization = "You are not authorized";
const String badRequest = "Oops something went wrong please try after sometime";
const String internalServer =
    "Oops something went wrong please try after sometime";
const String unKnow = "Oops something went wrong please try after sometime";
const String somethingWrong =
    "Oops something went wrong please try after sometime";
const String cancel = "Request is cancelled";
const String dataException = "No Record Found";
const String notFound = "No Record Found";
const String noDataFound = "No Record Found";
const String invalidUseridPassword = "Invalid username or password";
const String internetError = "Please enable your internet";
const String payRollLock =
    "Payroll activities are in progress. You will not be able to update/approve any data. However, you can view past data";
const String feedbackSuccess = "feedback submitted successfully";
