import 'package:demo_project/data/network/constant.dart';
import 'package:dio/dio.dart';

import 'response.dart';

class ErrorHandler {
  static response(DioException exception) {
    try {
      String? message;

      switch (exception.type) {
        case DioExceptionType.connectionTimeout:
        case DioExceptionType.sendTimeout:
        case DioExceptionType.receiveTimeout:
          return CustomResponse(
            success: false,
            message: connectionTimeout,
            data: null,
            fullResponse: connectionTimeout,
          );

        case DioExceptionType.badResponse:
          switch (exception.response?.statusCode) {
            case 400:
              // Logger.writeLog("TTTTTTTT" + exception.response.toString());
              // if (exception.response is Map) {
              //   message = exception.response?.data["error_description"] != null
              //       ? (exception.response?.data["error_description"] is String
              //           ? exception.response?.data["error_description"]
              //           : badrequest)
              //       : badrequest;
              // }

              return CustomResponse(
                success: false,
                message: message,
                data: null,
                fullResponse: exception.response?.data,
              );
            case 401:
              if (exception.response?.data is Map) {
                // message = exception.response?.data["error_description"] != null
                //     ? exception.response?.data["error_description"]
                //     : unauthorization;
              }
              return CustomResponse(
                success: false,
                message: message,
                data: null,
                fullResponse: null,
              );
            case 404:
              if (exception.response?.data is Map) {
                // message = exception.response?.data["error_description"] != null
                //     ? exception.response?.data["error_description"]
                //     : notFound;
              }
              return CustomResponse(
                success: false,
                message: message,
                data: null,
                fullResponse: exception.response?.data,
              );
            case 417:
              if (exception.response?.data is Map) {
                // message = exception.response?.data["error_description"] != null
                //     ? exception.response?.data["error_description"]
                //     : notFound;
              }
              return CustomResponse(
                success: false,
                message: message,
                data: null,
                fullResponse: exception.response?.data,
              );
            case 500:
              if (exception.response?.data is Map) {
                // message = exception.response?.data["error_description"] != null
                //     ? exception.response?.data["error_description"]
                //     : exception.requestOptions.path == ApiEndPoint.LOGIN_URL
                //         ? invalidUseridPassword
                //         : internalServer;
              }
              return CustomResponse(
                success: false,
                message: message,
                data: null,
                fullResponse: null,
              );
            default:
              if (exception.response != null) {
                return CustomResponse(
                  success: false,
                  message:
                      "exception.response?.statusMessage != null ? exception.response?.statusMessage: unknow",
                  data: null,
                  fullResponse: exception.response?.statusMessage != null
                      ? exception.response?.statusMessage.toString()
                      : exception.response.toString(),
                );
              } else {
                return CustomResponse(
                  success: false,
                  message: unKnow,
                  data: null,
                  fullResponse: exception.response.toString(),
                );
              }
          }
        case DioExceptionType.cancel:
          return CustomResponse(
            success: false,
            message: cancel,
            data: null,
            fullResponse: null,
          );
        case DioExceptionType.unknown:
          return CustomResponse(
            success: false,
            message: somethingWrong,
            data: null,
            fullResponse: null,
          );
        default:
          {}
      }
    } on Exception catch (error) {
      //Logger.writeLog('errorOth: $error');
      return CustomResponse(
          success: false,
          message: "unknow",
          data: null,
          fullResponse: error.toString());
    }
  }
}
