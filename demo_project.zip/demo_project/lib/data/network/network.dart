import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:demo_project/data/network/constant.dart';
import 'package:demo_project/data/network/error.dart';
import 'package:demo_project/data/network/response.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

enum HTTPMETHOD { GET, POST, PUT, DELETE, BYTE, BYTE_POST }

final apiBaseHelper = ApiBaseHelper();

class ApiBaseHelper {
  static BaseOptions opts = BaseOptions(
    responseType: ResponseType.json,
    connectTimeout: const Duration(minutes: 1),
    receiveTimeout: const Duration(minutes: 1),
  );

  static Dio createDio() {
    return Dio(opts);
  }

  static addInterceptors(Dio dio) {
    // dio.httpClientAdapter = DefaultHttpClientAdapter()
    //   ..onHttpClientCreate = (HttpClient client) {
    //     client.badCertificateCallback =
    //         (X509Certificate cert, String host, int port) => true;
    //     return client;
    //   };
    // dio.httpClientAdapter = DefaultHttpClientAdapter()
    //   ..createHttpClient = (HttpClient client) {
    //     client.badCertificateCallback =
    //         (X509Certificate cert, String host, int port) => true;
    //     return client;
    //   } as CreateHttpClient?;
    dio.interceptors.add(LoggingInterceptor());
    return dio;
  }

  static final dio = createDio();

  static final Dio baseAPI = addInterceptors(dio);

  Future<CustomResponse> request({
    String? url,
    dynamic data,
    Map<String, dynamic>? headers,
    bool isCookie = true,
    HTTPMETHOD method = HTTPMETHOD.GET,
    String? contentType,
  }) async {
    Response? response;
    try {
      // Logger.logLongString(url ?? "");
      // var language = {
      //   'Accept-Language': LocalizationService()
      //       .getLocaleFromLanguage(PrefData().getLanguage())!
      //       .languageCode
      // };
      // headers!.addAll(language);

      // Check For Network

      print(await checkInternetConnectivity());
      if (!await checkInternetConnectivity()) {
        print("Check network");

        return CustomResponse(
          message: internetError,
          data: null,
          success: false,
          fullResponse: null,
        );
      }
      switch (method) {
        case HTTPMETHOD.GET:
          response = await baseAPI.get(
            url!,
            options: Options(
                headers: headers,
                contentType: contentType ?? Headers.jsonContentType),
          );
          break;
        case HTTPMETHOD.POST:
          print("post");

          response = await baseAPI.post(
            url!,
            data: data,
            options: Options(
                headers: headers,
                contentType: contentType ?? Headers.jsonContentType),
          );
          break;
        case HTTPMETHOD.PUT:
          response = await baseAPI.put(
            url!,
            data: data,
            options: Options(
                headers: headers,
                contentType: contentType ?? Headers.jsonContentType),
          );

          print(response.statusCode);

          break;
        case HTTPMETHOD.DELETE:
          response = await baseAPI.delete(
            url!,
            data: data,
            options: Options(
                headers: headers,
                contentType: contentType ?? Headers.jsonContentType),
          );

          print(response);
          break;
        case HTTPMETHOD.BYTE:
          response = await baseAPI.get(
            url!,
            options: Options(
                headers: headers,
                responseType: ResponseType.bytes,
                contentType: contentType ?? Headers.jsonContentType),
          );
          break;
        case HTTPMETHOD.BYTE_POST:
          response = await baseAPI.post(
            url!,
            data: data,
            options: Options(
                headers: headers,
                responseType: ResponseType.bytes,
                contentType: contentType ?? Headers.jsonContentType),
          );
          break;
        default:
      }

      final resCode = response?.data is Map ? response?.data["code"] : "";
      final resMessage = response?.data is Map ? response?.data["message"] : "";
      final resData = response?.data is Map ? response?.data["result"] : "";
      return CustomResponse(
        success: true,
        code: resCode,
        message: resMessage,
        data: resData,
        fullResponse: response,
      );
    } on DioError catch (error) {
      // print("Switch");
      //
      // print(error);

      if (error.response?.statusCode == 401) {
        //logout user
        // Navigator.pushNamedAndRemoveUntil(
        // navigatorKey.currentContext!, loginScreen, (Route<dynamic> route) => false,
        // arguments: true
        // );
      }
      return ErrorHandler.response(error);
    }
  }

  Future<bool> checkInternetConnectivity() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.mobile) {
      return true;
    } else if (connectivityResult == ConnectivityResult.wifi) {
      return true;
    } else if (connectivityResult == ConnectivityResult.none) {
      return false;
    } else {
      return false;
    }
  }
}

class LoggingInterceptor extends Interceptor {
  int _maxCharactersPerLine = 200;

  @override
  void onRequest(
      RequestOptions options, RequestInterceptorHandler handler) async {
    // Logger.writeLog("--> ${options.method} ${options.path}");
    // Logger.writeLog("Content type: ${options.contentType}");
    // Logger.writeLog("header: ${options.headers}");
    //
    //
    // print("Flutter Framework");
    // print(options.headers.toString());
    // log(options.headers.toString());
    //
    // print(options.data);

    //
    // Logger.writeLog("body: ${options.data}");
    // Logger.writeLog("<-- END HTTP");
    return super.onRequest(options, handler);
  }

  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    // Logger.writeLog(
    //     "<-- ${response.statusCode} ${response.requestOptions.method} ${response.requestOptions.path}");
    // String responseAsString = response.data.toString();
    // if (responseAsString.length > _maxCharactersPerLine) {
    //   Logger.logLongString(responseAsString);
    // } else {
    //   Logger.writeLog(response.data.toString());
    // }
    // Logger.writeLog("<-- END HTTP");
    return super.onResponse(response, handler);
  }

  @override
  Future onError(DioError err, ErrorInterceptorHandler handler) async {
    //  print(err);

    // Logger.writeLog("<-- Error -->");
    // Logger.writeLog(err.error.toString());
    // Logger.writeLog(err.message.toString());
    return super.onError(err, handler);
  }
}
