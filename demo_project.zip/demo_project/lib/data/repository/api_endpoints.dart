class ApiEndpoints {
  static const String apiPath = "https://authorization.minervaiotstaging.com";
  static const String token = "$apiPath/oauth/token";
  static const String login = "$apiPath/oauth/token?";
}

class AppConstant {
  static const String userName = "fc5a4b7e86134d5fb794d9f7bdcda322";
  static const String passWord =
      "9IF0r7aTrvXoCtofzxS7r8KKRR4jOpV815k5prTtWR4IVXZ6JxXWdoYWR46ojpJAVUvTQR4d182i9FY8kOpItx8GbpD138OfrNKmtmMwliuBHHNXoDX2XYTUOqlBtbb6";
  static const String templateID = "tem_GKbGQ7yGmcjM33xFv9DSbpmX";
  static const String templateName = "Registration OTP Template";
  static const String templateSubject = "Your OTP from ZKBio iCare {{otp}}";
  static const String templateTextContent =
      "{{otp}} is the One Time Password(OTP) for your registration.This can be used one time only and is valid for 5 mins";
  static const String senderName = "MinervaIOT";
  static const String senderReplyTo = "info@zkteco.in";
  static const String inviteTemplateID = "tem_GKbGQ7yGmcjM33xFv9DSbpmX";

  //static final String inviteTemplateID = "tem_fqKBcbrrk78SjPcwj6xgfvFG";
  static const String inviteTemplateName = "Invite To Active Template";
  static const String inviteTemplateSubject =
      "Administrator has invited you to join them";
  static const String inviteTemplateTextContent =
      "{{name}} your team is waiting for you to join them.Administrator has invited you to collaborate";
  static const String siteTypeId = "000000007ba56d10017c597c0074008e";
  static const String addressTypeId = "000000007ba56d10017c597f1c000090";

  static const String adminRoleId = "000000007e4dff04017e4dff5c220000";
  static const String employeeRoleId = "000000007e4dff04017e4dff5c380002";
  static const int pageSize = 10;
}
