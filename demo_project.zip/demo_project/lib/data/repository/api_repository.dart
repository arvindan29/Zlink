
import '../network/network.dart';
import 'i_api_repository.dart';

ApiRepository apiRepository = ApiRepository(apiBaseHelper: apiBaseHelper);


class ApiRepository extends IApiRepository {
  late ApiBaseHelper apiBaseHelper;

  ApiRepository({required this.apiBaseHelper});

}