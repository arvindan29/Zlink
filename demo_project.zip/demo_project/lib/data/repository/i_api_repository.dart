

abstract class IApiRepository {}