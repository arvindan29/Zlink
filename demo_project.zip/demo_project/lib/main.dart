
import 'package:demo_project/presentations/controllers/login_controller/login_controller_bloc.dart';
import 'package:demo_project/router/router_file.dart';
import 'package:demo_project/themes/theme.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  runApp(MultiBlocProvider(providers: [
    BlocProvider(create: (context) => LoginControllerBloc()),
  ], child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Zlink',
      theme: ThemeClass.lightTheme(),
      initialRoute: splashScreen,
      routes: routes(context),
    );
  }
}
