import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';

part 'login_controller_event.dart';
part 'login_controller_state.dart';

class LoginControllerBloc extends Bloc<LoginControllerEvent, LoginControllerState> {
  LoginControllerBloc() : super(LoginControllerInitial()) {
    on<LoginControllerEvent>((event, emit) {});
  }

  ///form key
  final loginFormKey = GlobalKey<FormState>();
}
