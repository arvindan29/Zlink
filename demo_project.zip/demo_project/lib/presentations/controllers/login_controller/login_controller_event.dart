part of 'login_controller_bloc.dart';

abstract class LoginControllerEvent extends Equatable {
  const LoginControllerEvent();
}
