part of 'login_controller_bloc.dart';

abstract class LoginControllerState extends Equatable {
  const LoginControllerState();
}

class LoginControllerInitial extends LoginControllerState {
  @override
  List<Object> get props => [];
}
