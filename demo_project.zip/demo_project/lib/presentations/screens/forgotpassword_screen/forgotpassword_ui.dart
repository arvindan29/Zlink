import 'package:demo_project/utils/constants/assets_path.dart';
import 'package:demo_project/widgets/common_widget.dart';
import 'package:flutter/material.dart';

import '../../../widgets/app_color.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
          child: Form(
              child: ListView(
        children: [
          const SizedBox(
            height: 100,
          ),
          Center(
            child: SizedBox(
              width: 200,
              child: Image.asset(loginScreenLogo),
            ),
          ),
          const SizedBox(
            height: defaultPadding,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Text(
                  "Forgot Password",
                  style: Theme.of(context)
                      .textTheme
                      .titleLarge
                      ?.copyWith(fontSize: 20),
                ),
              ],
            ),
          ),
          const SizedBox(
            height: 25,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              "System will send a link to reset your password to the email or "
              "mobile used in your account, please check it carefully.",
              style: Theme.of(context)
                  .textTheme
                  .titleSmall
                  ?.copyWith(fontSize: 16),
            ),
          ),
          const SizedBox(
            height: defaultPadding,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                RichText(
                    text: TextSpan(
                        text: "Email",
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(fontSize: 16),
                        children: const [
                      TextSpan(
                          text: "*",
                          style: TextStyle(color: Colors.red, fontSize: 16))
                    ]))
              ],
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: MTextFormField(
              hint: "Enter Your Email",
            ),
          ),
          const SizedBox(
            height: defaultPadding,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: MElevatedButton(
              onPressed: () {},
              child: Text("Send",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(color: Colors.white, fontSize: 16)),
            ),
          ),
          const SizedBox(
            height: defaultPadding,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: MOutLineButton(
              onPressed: () {
                Navigator.pop(context);
              },
              sideColor: Colors.green,
              radius: 8,
              widget: Padding(
                padding: const EdgeInsets.only(top: 12, bottom: 12),
                child: Text("Back to Login",
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontSize: 12)),
              ),
            ),
          ),
          const SizedBox(
            height: defaultPadding,
          ),
        ],
      ))),
    );
  }
}
