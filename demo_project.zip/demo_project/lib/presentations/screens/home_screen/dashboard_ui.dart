import 'package:demo_project/widgets/common_widget.dart';
import 'package:flutter/material.dart';

import '../../../themes/theme.dart';
import '../../../utils/constants/assets_path.dart';
import '../../../widgets/custom_dialog/dialog_sheet.dart';
import 'drawer/account_profile_screen/account_profile_ui.dart';
import 'drawer/organization_profile_screen/organization_profile_ui.dart';
import 'drawer/reset_password_screen/reset_password_ui.dart';
import 'drawer/switch_organization_screen/switch_organization_ui.dart';

class DashBoardScreen extends StatefulWidget {
  const DashBoardScreen({super.key});

  @override
  State<DashBoardScreen> createState() => _DashBoardScreenState();
}

class _DashBoardScreenState extends State<DashBoardScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: MAppBar(
          title: Text("Dashboard",
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontSize: 22)),
        ),
        drawer: Drawer(
          backgroundColor: Colors.white,
          child: ListView(
            children: [
              const UserAccountsDrawerHeader(
                accountName: Text('Aravindan V'),
                accountEmail: Text('aravindan@zktecodev.com'),
                currentAccountPicture: CircleAvatar(
                    // backgroundImage: AssetImage("assets/Images/profilePic.jpg"),
                    ),
              ),
              ListTile(
                leading: const Icon(Icons.person),
                title: Text(
                  "Account profile",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 18),
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const AccountProfileScreen()));
                },
              ),
              ListTile(
                leading: const Icon(Icons.key),
                title: Text(
                  "Reset password",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 18),
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ResetPasswordScreen()));
                },
              ),
              ListTile(
                leading: const Icon(Icons.key_off),
                title: Text(
                  "Exit from organization",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 18),
                ),
                onTap: () {},
              ),
              ListTile(
                leading: const Icon(Icons.logout),
                title: Text(
                  "Logout",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 18),
                ),
                onTap: () {},
              ),
              const Divider(),
              ListTile(
                title: Text(
                  "Current organization",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 16),
                ),
                onTap: () {},
              ),
              ListTile(
                leading: const Icon(Icons.home),
                title: Text(
                  "Organization profile",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 18),
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              const OrganizationProfileScreen()));
                },
              ),
              ListTile(
                leading: const Icon(Icons.home),
                title: Text(
                  "Switch organization",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 18),
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              const SwitchOrganizationScreen()));
                },
              ),
              ListTile(
                leading: const Icon(Icons.home),
                title: Text(
                  "Create organization",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 18),
                ),
                onTap: () {},
              ),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.language),
                title: Text(
                  "Switch language",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 18),
                ),
                onTap: () {},
              ),
              ListTile(
                leading: const Icon(Icons.settings),
                title: Text(
                  "Settings",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 18),
                ),
                onTap: () {},
              ),
              ListTile(
                leading: const Icon(Icons.account_box_outlined),
                title: Text(
                  "About",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 18),
                ),
                onTap: () {},
              ),
              ListTile(
                leading: const Icon(Icons.contact_support),
                title: Text(
                  "Contact us",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 18),
                ),
                onTap: () {},
              ),
            ],
          ),
        ),
        // body: MOutLineButton(
        //   onPressed: () {
        //     showAlertDialog(
        //       circleAvatarImage: const SizedBox(),
        //       title: "Logout",
        //       subtitle: "Are you sure you want to Logout?",
        //       context: context,
        //       actionButtonName: "Yes",
        //       cancelButtonName: "No",
        //       onPressedNo: () {
        //         Navigator.pop(context);
        //       },
        //       onPressedYes: () {
        //
        //       },
        //     );
        //   },
        //   sideColor: ThemeClass.green.withOpacity(.6),
        //   radius: 8,
        //   widget: Padding(
        //     padding: const EdgeInsets.only(top: 18, bottom: 18),
        //     child: Row(
        //       mainAxisAlignment: MainAxisAlignment.center,
        //       children: [
        //         const MSvgImage(
        //           path: logOutIcon,
        //         ),
        //         const SizedBox(
        //           width: 10,
        //         ),
        //         Text(
        //           "Logout",
        //           style: Theme.of(context).textTheme.titleSmall?.copyWith(
        //             fontSize: 18,
        //             color: ThemeClass.green,
        //           ),
        //         )
        //       ],
        //     ),
        //   ),
        // ),
      ),
    );
  }
}
