import 'package:demo_project/widgets/common_widget.dart';
import 'package:flutter/material.dart';

class AccountProfileScreen extends StatefulWidget {
  const AccountProfileScreen({super.key});

  @override
  State<AccountProfileScreen> createState() => _AccountProfileScreenState();
}

class _AccountProfileScreenState extends State<AccountProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: MAppBar(
          title: Text("Account Profile",
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontSize: 20)),
        ),
        body: ListView(
          children: const [
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MTextFormField(
                readOnly: true,
                suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
                hint: "View My Profile",
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MTextFormField(
                readOnly: true,
                suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
                hint: "Edit My Profile",
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MTextFormField(
                readOnly: true,
                suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
                hint: "Delete this Account",
              ),
            ),
          ],
        ),
      ),
    );
  }
}
