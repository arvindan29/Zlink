import 'package:flutter/material.dart';

import '../../../../../widgets/common_widget.dart';

class OrganizationProfileScreen extends StatefulWidget {
  const OrganizationProfileScreen({super.key});

  @override
  State<OrganizationProfileScreen> createState() => _OrganizationProfileScreenState();
}

class _OrganizationProfileScreenState extends State<OrganizationProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: MAppBar(
          title: Text("Organization Profile",
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontSize: 20)),
        ),
        body: ListView(
          children: const [
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MTextFormField(
                readOnly: true,
                suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
                hint: "View Organization Profile",
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MTextFormField(
                readOnly: true,
                suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
                hint: "Edit Organization Profile",
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MTextFormField(
                readOnly: true,
                suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
                hint: "Delete Organization Account",
              ),
            ),
          ],
        ),
      ),
    );
  }
}
