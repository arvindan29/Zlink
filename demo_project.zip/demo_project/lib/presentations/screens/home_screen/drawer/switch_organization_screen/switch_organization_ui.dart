import 'package:flutter/material.dart';


class SwitchOrganizationScreen extends StatefulWidget {
  const SwitchOrganizationScreen({super.key});

  @override
  State<SwitchOrganizationScreen> createState() => _SwitchOrganizationScreenState();
}

class _SwitchOrganizationScreenState extends State<SwitchOrganizationScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
