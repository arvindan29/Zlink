import 'package:demo_project/presentations/screens/forgotpassword_screen/forgotpassword_ui.dart';
import 'package:demo_project/presentations/screens/organization_screen/organization_select.dart';
import 'package:demo_project/presentations/screens/signup_screen/signup_ui.dart';
import 'package:demo_project/themes/theme.dart';
import 'package:demo_project/utils/constants/assets_path.dart';
import 'package:demo_project/widgets/app_color.dart';
import 'package:demo_project/widgets/common_widget.dart';
import 'package:demo_project/widgets/ui_labeled_checkedbox.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../controllers/login_controller/login_controller_bloc.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    var loginBloc = BlocProvider.of<LoginControllerBloc>(context, listen: true);

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Form(
          key: loginBloc.loginFormKey,
          child: ListView(
            children: [
              const SizedBox(
                height: defaultPadding,
              ),
              Center(
                child: SizedBox(
                  width: 200,
                  child: Image.asset(loginScreenLogo),
                ),
              ),
              const SizedBox(
                height: 50,
                // height: defaultPadding,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Text(
                      "Welcome",
                      style: Theme.of(context)
                          .textTheme
                          .titleLarge
                          ?.copyWith(fontSize: 24),
                    )
                  ],
                ),
              ),
              const SizedBox(
                height: defaultPadding,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    RichText(
                        text: TextSpan(
                            text: "Email",
                            style: Theme.of(context)
                                .textTheme
                                .titleSmall
                                ?.copyWith(fontSize: 18),
                            children: const [
                          TextSpan(
                              text: "*", style: TextStyle(color: Colors.red))
                        ])),
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: MTextFormField(
                  hint: "Enter Your Email",
                ),
              ),
              const SizedBox(
                height: defaultPadding,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Text(
                      "Password",
                      style: Theme.of(context)
                          .textTheme
                          .titleSmall
                          ?.copyWith(fontSize: 18),
                    )
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: MTextFormField(
                  hint: "Enter Your Password",
                  suffixIcon: IconButton(
                      onPressed: () {}, icon: const Icon(Icons.remove_red_eye)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Row(
                  children: [
                    IconButton(
                        onPressed: () {},
                        icon: const Icon(
                          Icons.check_box_outline_blank,
                          color: Colors.lightGreen,
                        )),
                    Text(
                      "Auto login in 5 days",
                      style: Theme.of(context)
                          .textTheme
                          .titleSmall
                          ?.copyWith(fontSize: 14),
                    ),
                    const Spacer(),
                    TextButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const ForgotPasswordScreen()));
                        },
                        child: const Text("Forgot Password?"))
                  ],
                ),
              ),
              const SizedBox(
                height: defaultPadding,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: MElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  const OrganizationSelect()));
                    },
                    child: const Text(
                      "Login",
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    )),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Not yet have account?",
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontSize: 16, color: ThemeClass.black.withOpacity(0.9)),
                  ),
                  TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const SignupScreen()));
                      },
                      child: const Text(
                        "Create Account",
                        style: TextStyle(fontSize: 16),
                      ))
                ],
              ),
              const SizedBox(height: 50),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Compliance with ISO27001",
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontSize: 14, color: ThemeClass.black.withOpacity(0.9)),
                  ),
                  TextButton(
                      onPressed: () {},
                      child: const Text(
                        "Know more about this?",
                        style: TextStyle(fontSize: 14),
                      ))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
