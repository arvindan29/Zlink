import 'package:demo_project/presentations/screens/login_screen/login_ui.dart';
import 'package:demo_project/presentations/screens/organization_screen/organization_select.dart';
import 'package:demo_project/utils/constants/assets_path.dart';
import 'package:demo_project/widgets/app_color.dart';
import 'package:demo_project/widgets/common_widget.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class OrganizationCreate extends StatefulWidget {
  const OrganizationCreate({super.key});

  @override
  State<OrganizationCreate> createState() => _OrganizationCreateState();
}

class _OrganizationCreateState extends State<OrganizationCreate> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: ListView(
          children: [
            const SizedBox(
              height: defaultPadding,
            ),
            Center(
              child: Image.asset(loginScreenLogo),
            ),
            const SizedBox(
              height: defaultPadding,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  Text(
                    "Create Organization",
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontSize: 20),
                  )
                ],
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                "Organization Name",
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontSize: 16),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MTextFormField(
                hint: "Organization Name",
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                "Organization Code",
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontSize: 16),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: MTextFormField(
                hint: "Organization Code",
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: MElevatedButton(
                onPressed: () {},
                child: Text("Login",
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontSize: 16, color: Colors.white)),
              ),
            ),
            const SizedBox(
              height: defaultPadding,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Already have an organization?",
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontSize: 16),
                ),
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  const OrganizationSelect()));
                    },
                    child: Text(
                      "Select Organization",
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontSize: 16, color: Colors.green),
                    ))
              ],
            ),
            const SizedBox(
              height: defaultPadding,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: MOutLineButton(
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const LoginScreen()));
                },
                radius: 8,
                sideColor: Colors.green,
                widget: Padding(
                  padding: const EdgeInsets.only(top: 12, bottom: 12),
                  child: Text("Back to Login",
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontSize: 16)),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
