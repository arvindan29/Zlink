import 'package:demo_project/presentations/screens/home_screen/dashboard_ui.dart';
import 'package:demo_project/presentations/screens/login_screen/login_ui.dart';
import 'package:demo_project/presentations/screens/organization_screen/organization_create.dart';
import 'package:demo_project/presentations/screens/organization_screen/organization_select.dart';
import 'package:demo_project/utils/constants/assets_path.dart';
import 'package:demo_project/widgets/app_color.dart';
import 'package:demo_project/widgets/common_widget.dart';
import 'package:flutter/material.dart';

class OrganizationSelect extends StatefulWidget {
  const OrganizationSelect({super.key});

  @override
  State<OrganizationSelect> createState() => _OrganizationSelectState();
}

class _OrganizationSelectState extends State<OrganizationSelect> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(onPressed: (){
        Navigator.push(context, MaterialPageRoute(builder: (context)=> DashBoardScreen()));
      }),
      backgroundColor: Colors.white,
      body: SafeArea(
          child: Form(
              child: ListView(
        children: [
          Column(
            children: [
              const SizedBox(
                height: 70,
              ),
              Center(
                child: Image.asset(loginScreenLogo),
              ),
              const SizedBox(
                height: defaultPadding,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Text(
                      "Select Organization",
                      style: Theme.of(context)
                          .textTheme
                          .titleLarge
                          ?.copyWith(fontSize: 22),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  "Please select the organization you created and enter this organization.",
                  style: Theme.of(context)
                      .textTheme
                      .titleSmall
                      ?.copyWith(fontSize: 16),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  "You can also switch between your multiple organizations after logging in.",
                  style: Theme.of(context)
                      .textTheme
                      .titleSmall
                      ?.copyWith(fontSize: 16),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Row(
                  children: [
                    Text(
                      "Organization Name",
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontSize: 16),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: MTextFormField(
                  hint: "Select Organization Name",
                  suffixIcon: Icon(Icons.keyboard_arrow_down_outlined),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width,
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: MElevatedButton(
                    onPressed: () {},
                    child: Text("Enter",
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(fontSize: 16, color: Colors.white)),
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Don't have an organization?",
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontSize: 16),
                  ),
                  TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    const OrganizationCreate()));
                      },
                      child: Text(
                        "Create One",
                        style: Theme.of(context)
                            .textTheme
                            .titleMedium
                            ?.copyWith(fontSize: 16, color: Colors.green),
                      )),
                ],
              ),
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: MOutLineButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => const LoginScreen()));
              },
              radius: 8,
              sideColor: Colors.green,
              widget: Padding(
                padding: const EdgeInsets.only(top: 12, bottom: 12),
                child: Text("Back to Login",
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontSize: 16,
                        )),
              ),
            ),
          )
        ],
      ))),
    );
  }
}
