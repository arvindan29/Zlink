import 'package:demo_project/presentations/screens/login_screen/login_ui.dart';
import 'package:demo_project/presentations/screens/splash_screen/splash_ui.dart';
import 'package:flutter/material.dart';

const loginScreen = "LoginScreen";
const splashScreen = "SplashScreen";


Map<String, Widget Function(BuildContext)> routes(BuildContext context) {
  return {
    splashScreen: (context) => const SplashScreen(),
    loginScreen: (context) => const LoginScreen()
  };
}