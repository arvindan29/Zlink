import 'package:flutter/material.dart';

class Loading {
  ///Full screen Loading
  fullScreenLoading({
    EdgeInsets padding = const EdgeInsets.only(top: 0),
    Color bgColor = Colors.white,
  }) {
    return Container(
      //margin: padding,
      color: bgColor,
      child: const Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}
