import 'dart:convert';

/// for finding is there any errors are fond in API response
bool containsErrorMessage(String? responseCode) {
  if (responseCode != null) {
    String msgIdentifier = responseCode.substring(3, 4);
    if (msgIdentifier == 'E') {
      return true;
    } else {
      return false;
    }
  }
  return false;
}

/// JWT access token parsing mechanism=====

Map<String, dynamic> parseJwt(String token) {
  final parts = token.split('.');
  if (parts.length != 3) {
    throw Exception('invalid token');
  }

  final payload = _decodeBase64(parts[1]);
  final payloadMap = json.decode(payload);
  if (payloadMap is! Map<String, dynamic>) {
    throw Exception('invalid payload');
  }

  return payloadMap;
}

String _decodeBase64(String str) {
  String output = str.replaceAll('-', '+').replaceAll('_', '/');

  switch (output.length % 4) {
    case 0:
      break;
    case 2:
      output += '==';
      break;
    case 3:
      output += '=';
      break;
    default:
      throw Exception('Illegal base64url string!"');
  }

  return utf8.decode(base64Url.decode(output));
}

///Email_Validation
bool isEmail(String string) {
  // Null or empty string is invalid
  if (string == null || string.isEmpty) {
    return false;
  }

  const pattern = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';
  final regExp = RegExp(pattern);

  if (!regExp.hasMatch(string)) {
    return false;
  }
  return true;
}

String? validatorEmail(String? value) {
  if (value == null || value.isEmpty) {
    return 'Please Enter Valid Email';
  } else if (!isEmail(value)) {
    return 'Please enter valid Email ID';
  }
  return null;
}

///PhoneNumber_Validation
bool isValidPhoneNumber(String string) {
  // Null or empty string is invalid phone number
  if (string == null || string.isEmpty) {
    return false;
  }

  // You may need to change this pattern to fit your requirement.
  // I just copied the pattern from here: https://regexr.com/3c53v
  /// const pattern = r'(^(?:[+0]9)?[0-9]{10,12}$)';
  const pattern = r'^(\+\d{1,3}[- ]?)?\d{10}$';
  final regExp = RegExp(pattern);

  if (!regExp.hasMatch(string)) {
    return false;
  }
  return true;
}

///FirstName_Validation
String? validateFirstName(String? value) {
  if (value == null || value.isEmpty) {
    return 'Please Enter First Name';
  }
}

///LastName_Validation
String? validateLastName(String? value) {
  if (value == null || value.isEmpty) {
    return 'Please Enter Last Name';
  }
}

///CompanyName_Validation
String? validateCompanyName(String? value) {
  if (value == null || value.isEmpty) {
    return 'Please Enter Company Name';
  }
}

///CountryName_Validation
String? validateCountryName(String? value) {
  if (value == null || value.isEmpty) {
    return 'Please Select Country';
  }
}

///DepartmentName_Validation
String? departmentName(String? value) {
  if (value == null || value.isEmpty) {
    return 'Please Enter Field';
  }
  const pattern = r'^[a-zA-Z0-9\s]+$';
  final regExp = RegExp(pattern);
  if (!regExp.hasMatch(value)) {
    return 'No Special Character Allowed';
  }
  return null;
}

///Password_Validation
bool isPasswordCompliant(String string) {
  if (string == null || string.isEmpty) {
    return false;
  }
  const pattern =
      r'^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[!@#\$&*~]).{8,}$';
  final regExp = RegExp(pattern);

  if (!regExp.hasMatch(string)) {
    return false;
  }
  return true;
}

bool isPassWordValidate = false;
bool isOtpValidate = false;

String? validatorPassword(String? value) {
  if (value == null || value.isEmpty) {
    return 'Please Enter Valid Password';
  }
  isPassWordValidate = true;
  return null;
}

String? validatorOtp(String? value) {
  if (value == null) {
  } else if (value.length != 6) {
    return "Please enter valid OTP";
  } else {
    return null;
  }
}

String? createPassword(String? value) {
  if (value == null || value.isEmpty) {
    return 'Please Enter Your Password';
  }
  if (!isPasswordCompliant(value)) {
    return 'Password should contains at least 8 characters , including upper / lower case, numbers , special char';
  }
  return null;
}

///Staff_Validation
String? validateStaffName(String? value) {
  if (value == null || value.isEmpty) {
    return 'Please Enter Staff Name';
  }
}

String? validateStaffID(String? value) {
  if (value == null || value.isEmpty) {
    return 'Please Enter Staff Name';
  }
  const pattern = r'^[a-zA-Z0-9\s]+$';
  final regExp = RegExp(pattern);
  if (!regExp.hasMatch(value)) {
    return 'No Speical Character Allowed';
  }
  return null;
}

String? validateStaffPhone(String? val) {
  if (val == null || val.isEmpty) {
    return "Please enter valid phone number";
  }
  if (!isValidPhoneNumber(val)) {
    return "Please enter valid phone number";
  }
}
