import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ThemeClass {
  static Color green = const Color(0xff76B745);
  static Color black = const Color(0xff474A4E);
  static Color cream = const Color(0xffFFE1D4);

  static ThemeData lightTheme() {
    return ThemeData(
      colorScheme: ColorScheme.fromSeed(
        seedColor: green,
      ),
      useMaterial3: true,
      textTheme: TextTheme(
          titleLarge: GoogleFonts.roboto(
              fontWeight: FontWeight.w700, color: const Color(0xff474A4E)),
          titleMedium: GoogleFonts.roboto(
              fontWeight: FontWeight.w500, color: const Color(0xff474A4E)),
          titleSmall: GoogleFonts.roboto(
              fontWeight: FontWeight.w400, color: const Color(0xff474A4E))),
      scaffoldBackgroundColor: Colors.white,
      cardColor: Colors.grey[100],
      elevatedButtonTheme: const ElevatedButtonThemeData(
          style: ButtonStyle(
              backgroundColor: MaterialStatePropertyAll(Color(0xff76B745)))),

      // const Color(0xffE4E4E4)
    );
  }

  static ThemeData darkTheme() {
    return ThemeData();
  }
}
