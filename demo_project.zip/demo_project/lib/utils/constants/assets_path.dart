///splash logo
const splashScreenLogo = "assets/splashScreen/Logo.jpg";

///logo header
const loginScreenLogo = "assets/loginScreen/Logo.jpg";


///icons
const profile="assets/buttons/profile.svg";
const logOutIcon="assets/icons/logout.svg";


///reset password logo
const resetPasswordScreenLogo="assets/resedPasswordScreen/mobpwd.jpg";