import 'package:flutter/material.dart';

const Color ff265AC2 = Color(0xff265AC2);
const kShadowColor = Color(0xffD6D6D6);

const Color kPrimaryColor = Color(0xff78BC27);
const Color primaryColor = Color(0xFFFFC107);
const secondaryColor = Color(0xFF242430);
const bodyTextColor = Color(0xFF888880);
const darkColor = Color(0xFF191923);
const hqColor = Color(0xFF1E1E28);

const Color ff2D2D2D = Color(0xff2D2D2D);
const Color ff7C7C7C = Color(0xff7C7C7C);
const Color ffF3F3F3 = Color(0xffF3F3F3);
const Color ffFBFDff = Color(0xffFBFDff);
const Color ff3C3C3C = Color(0xff3C3C3C);
const Color ff74726E = Color(0xff74726E);
const Color ffD9D9D9 = Color(0xffD9D9D9);
const Color ff474A4E = Color(0xff474A4E);
const Color ff969696 = Color(0xff969696);
const Color ff7A7D80 = Color(0xff7A7D80);
const Color ffF5F5F5 = Color(0xffF5F5F5);
const Color ffE0E0E0 = Color(0xffE0E0E0);
const Color ff4FCCAF = Color(0xff4FCCAF);
const Color ffE3E3E3 = Color(0xffE3E3E3);
const Color ff15478A = Color(0xff15478A);
const Color ffD4D4D4 = Color(0xffD4D4D4);
const Color ffB60000 = Color(0xffB60000);

const Color ff757575 = Color(0xff757575);
const Color ffFDFDFD = Color(0xffFDFDFD);
const Color ff40739E = Color(0xff40739E);
const Color ffffC026 = Color(0xffffC026);
const Color ff676767 = Color(0xff676767);
const Color ff00C068 = Color(0xff00C068);
const Color ffff694E = Color(0xffff694E);
const Color ffCECFD0 = Color(0xffCECFD0);
const Color ffff793F = Color(0xffff793F);
const Color ffff5252 = Color(0xffff5252);
const Color ff9BD550 = Color(0xff9BD550);
const Color ff78BC27 = Color(0xff78BC27);
const Color ffF6F6F6 = Color(0xffF6F6F6);
const Color ff808080 = Color(0xff808080);
const Color ff808081 = Color(0x76B74508);
const Color ffffF0CC = Color(0xffffF0CC);
const Color ffEFEFEF = Color(0xffEFEFEF);
const Color ffD2D2D2 = Color(0xffD2D2D2);
const Color ffF7F7F7 = Color(0xffF7F7F7);
const Color ff5D5D5D = Color(0xff5D5D5D);
const Color ffE8E8E8 = Color(0xffE8E8E8);
const Color ffE2E2E2 = Color(0xffE2E2E2);
const Color ffD8D8D8 = Color(0xffD8D8D8);
const Color ffE6E6E6 = Color(0xffE6E6E6);

const defaultPadding = 30.0;
const defaultDuration = Duration(seconds: 1); // we use it on our animation
const maxWidth = 200.0; // max width of our web
