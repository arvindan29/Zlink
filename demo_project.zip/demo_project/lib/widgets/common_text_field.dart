import 'package:demo_project/widgets/app_color.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CommonTextField extends StatelessWidget {
  final String? label;
  final String hint;
  final TextInputType keyBoardType;
  final TextInputAction textInputAction;
  final int? maxLength;
  final List<TextInputFormatter>? inputFormat;
  final ValueChanged<String>? onChanged;
  final dynamic? errorText;
  final IconButton? suffixIcon, prefixIcon;
  final Color? borderColor;
  final TextEditingController? controller;
  final bool? readOnly;
  final GestureTapCallback? onTap;
  final EdgeInsets? contentPadding;
  final TextStyle? hintStyle, labelStyle, style;
  final int? maxlines;

  const CommonTextField(
      {Key? key,
      this.controller,
      required this.keyBoardType,
      required this.textInputAction,
      this.maxLength,
      this.label,
      required this.hint,
      this.errorText,
      required this.onChanged,
      this.inputFormat,
      this.suffixIcon,
      this.prefixIcon,
      this.borderColor,
      this.readOnly,
      this.onTap,
      this.contentPadding,
      this.hintStyle,
      this.labelStyle,
      this.style,
      this.maxlines})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        label != null
            ? Text(
                label!,
                style: labelStyle ??
                    Theme.of(context)
                        .textTheme
                        .headlineSmall
                        ?.copyWith(color: kPrimaryColor),
              )
            : SizedBox(),
        label != null ? SizedBox(height: defaultPadding) : SizedBox(),
        TextField(
          maxLines: maxlines ?? 1,
          controller: controller,
          onTap: onTap,
          readOnly: readOnly ?? false,
          onChanged: onChanged,
          keyboardType: keyBoardType,
          textInputAction: textInputAction,
          inputFormatters: inputFormat,
          maxLength: maxLength,
          style: style ??
              Theme.of(context)
                  .textTheme
                  .headlineSmall
                  ?.copyWith(color: kPrimaryColor),
          decoration: InputDecoration(
              fillColor: kPrimaryColor,
              filled: true,
              counterText: "",
              suffixIcon: suffixIcon,
              prefixIcon: prefixIcon,
              errorText: errorText,
              errorStyle: Theme.of(context)
                  .textTheme
                  .headlineSmall
                  ?.copyWith(color: kPrimaryColor),
              contentPadding: contentPadding ??
                  EdgeInsets.only(left: defaultPadding, right: defaultPadding),
              prefix: Padding(padding: EdgeInsets.only(left: defaultPadding)),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(defaultPadding),
                  borderSide: BorderSide(
                    width: defaultPadding,
                    color: borderColor ?? kPrimaryColor,
                  )),
              enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(defaultPadding),
                  borderSide: BorderSide(
                    width: defaultPadding,
                    color: borderColor ?? kPrimaryColor,
                  )),
              focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(defaultPadding),
                  borderSide: BorderSide(
                    width: defaultPadding,
                    color: borderColor ?? kPrimaryColor,
                  )),
              errorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(defaultPadding),
                  borderSide: BorderSide(
                    width: defaultPadding,
                    color: borderColor ?? kPrimaryColor,
                  )),
              focusedErrorBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(defaultPadding),
                  borderSide: BorderSide(
                    width: defaultPadding,
                    color: borderColor ?? kPrimaryColor,
                  )),
              hintText: hint,
              hintStyle: hintStyle ??
                  Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(color: kPrimaryColor)),
        ),
      ],
    );
  }
}
