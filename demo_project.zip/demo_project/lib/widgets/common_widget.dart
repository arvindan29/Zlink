import 'package:country_picker/country_picker.dart';
import 'package:demo_project/widgets/app_color.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';

///AppBar
class MAppBar extends StatelessWidget implements PreferredSizeWidget {
  // final Color backgroundColor = Colors.white;
  final Widget? title;
  final Widget? leading;
  final List<Widget>? widgets;

  const MAppBar({Key? key, this.title, this.widgets, this.leading})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      scrolledUnderElevation: 0,
      elevation: 0,
      title: title,
      backgroundColor: ffFBFDff,
      actions: widgets,
      leading: leading,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}

///OutlineButton
class MOutLineButton extends StatelessWidget {
  const MOutLineButton(
      {Key? key,
      this.widget,
      this.radius,
      this.sideColor,
      this.foregroundColor,
      this.padding,
      this.onPressed})
      : super(key: key);

  final Widget? widget;
  final double? radius;
  final Color? sideColor;

  final Color? foregroundColor;
  final EdgeInsetsGeometry? padding;
  final void Function()? onPressed;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        padding: padding ?? EdgeInsets.zero,
        foregroundColor: foregroundColor,
        visualDensity: const VisualDensity(
          horizontal: VisualDensity.minimumDensity,
          vertical: VisualDensity.minimumDensity,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(radius ?? 0),
        ),

        side: BorderSide(
            color: sideColor ?? const Color(0xFF2D2D2D),
            width: 2), //<-- SEE HERE
      ),
      // onPressed: () {},
      onPressed: onPressed,
      child: widget,
    );
  }
}

///SvgImage
class MSvgImage extends StatelessWidget {
  const MSvgImage({Key? key, this.path, this.colorFilter, this.color}) : super(key: key);

  final String? path;
  final ColorFilter? colorFilter;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    return SvgPicture.asset(path ?? "",
        semanticsLabel: 'Initial logo', colorFilter: colorFilter,);
  }
}

///TextFormField
class MTextFormField extends StatelessWidget {
  const MTextFormField(
      {Key? key,
      this.label,
      this.hint,
      this.radius = 4,
      this.prefixIcon,
      this.suffixIcon,
      this.value,
      this.controller,
      this.validator,
      this.maxLength = 50,
      this.textInputAction = TextInputAction.done,
      this.obscureText,
      this.onTap,
      this.readOnly = false,
      this.keyboardType,
      this.inputFormatters,
      this.onFieldSubmitted,
      this.onChanged})
      : super(key: key);

  final String? label;
  final String? hint;
  final double radius;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final bool? value;
  final TextEditingController? controller;
  final String? Function(String?)? validator;
  final bool? obscureText;
  final int maxLength;
  final TextInputAction textInputAction;
  final Function()? onTap;
  final bool readOnly;
  final TextInputType? keyboardType;
  final List<TextInputFormatter>? inputFormatters;
  final void Function(String)? onFieldSubmitted;
  final void Function(String)? onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextFormField(
            readOnly: readOnly,
            onTap:  onTap,
            maxLength: maxLength,
            controller: controller,
            validator: validator,
            textInputAction: textInputAction,
            onFieldSubmitted: onFieldSubmitted,
            keyboardType: keyboardType,
            inputFormatters: inputFormatters,
            onChanged: onChanged,
            style: GoogleFonts.roboto(),
            autovalidateMode: AutovalidateMode.onUserInteraction,
            decoration: InputDecoration(
              errorMaxLines: 2,
              prefixIcon: prefixIcon,
              suffixIcon: suffixIcon,
              counterText: "",
              contentPadding: const EdgeInsets.all(20),
              isDense: true,
              hintText: hint,
              hintStyle: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontSize: 16, color: Colors.grey[500]),
              labelStyle: const TextStyle(color: Color(0xff292D32)),
              label: label != null ? Text(label!) : null,

              ///Border Decoration
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(radius),
                borderSide: BorderSide(color: Colors.grey[200]!, width: 2),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(radius),
                borderSide: BorderSide(color: Colors.grey[200]!, width: 2),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(radius),
                // borderSide: BorderSide(color: Colors.grey[200]!, width: 2),
                borderSide: const BorderSide(color: ff78BC27),
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(radius),
                borderSide: const BorderSide(color: Colors.red, width: 2),
              ),
              // errorStyle: const TextStyle(height: 0),
            )),
      ],
    );
  }
}

///CircleAvatar
class CircularAvatarWidget extends StatelessWidget {
  final String imagePath;
  final double? radius;
  const CircularAvatarWidget({required this.imagePath,this.radius,Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      backgroundImage: AssetImage(imagePath),
      radius: radius??48,
    );
  }
}

///ElevatedButton
class MElevatedButton extends StatelessWidget {
  const MElevatedButton(
      {Key? key,
      this.child,
      this.elevation,
      this.backgroundColor,
      required this.onPressed})
      : super(key: key);
  final Widget? child;
  final double? elevation;
  final Color? backgroundColor;
  final Function onPressed;

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      onPressed: () {
        onPressed();
      },
      style: ButtonStyle(
          backgroundColor: MaterialStatePropertyAll(backgroundColor),
          elevation: MaterialStatePropertyAll(elevation),
          shape: MaterialStatePropertyAll(
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
          )),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 15),
        // margin: const EdgeInsets.symmetric(vertical: 10),
        child: child,
      ),
    );
  }
}

///PhonePrefix
Widget phonePrefix({
  isPopUpActive = true,
  required BuildContext context,
  required void Function(String countryName, String countryCode) onValuePicked,
  String? countryCode,
}) {
  return GestureDetector(
    onTap: () {
      if (isPopUpActive) {
        countryDialog(
            context: context,
            title: "Select your phone code",
            onValuePicked: onValuePicked);
      }
    },
    child: Row(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const SizedBox(width: 5),
        Text(
          "+${countryCode ?? ""}",
          style: Theme.of(context)
              .textTheme
              .headline6
              ?.copyWith(fontSize: 14, letterSpacing: 2),
        ),
        const SizedBox(width: 5),
        Container(
          margin: const EdgeInsets.only(top: 10, bottom: 10),
          color: Colors.grey,
          width: 2,
          height: 30,
        ),
        const SizedBox(
          width: 5,
        ),
      ],
    ),
  );
}

///CountryDialog
void countryDialog({
  required BuildContext context,
  required String title,
  bool isCountry = false,
  bool filter = false,
  required void Function(String countryName, String countryCode) onValuePicked,
}) {
  showCountryPicker(
    context: context,
    showPhoneCode: true,
    favorite: ['IN', 'CN'],
    countryListTheme: CountryListThemeData(
      flagSize: 25,
      backgroundColor: Colors.white,
      textStyle: const TextStyle(fontSize: 16, color: Colors.blueGrey),
      bottomSheetHeight: 500,
      // Optional. Country list modal height
      //Optional. Sets the border radius for the bottomsheet.
      borderRadius: const BorderRadius.only(
        topLeft: Radius.circular(20.0),
        topRight: Radius.circular(20.0),
      ),
      //Optional. Styles the search field.
      inputDecoration: InputDecoration(
        labelText: 'Search',
        hintText: 'Start typing to search',
        prefixIcon: const Icon(Icons.search),
        border: OutlineInputBorder(
          borderSide: BorderSide(
            color: const Color(0xFF8C98A8).withOpacity(0.2),
          ),
        ),
      ),
    ),
    onSelect: (Country country) {
      onValuePicked(country.name, country.phoneCode);
    },
  );
}
