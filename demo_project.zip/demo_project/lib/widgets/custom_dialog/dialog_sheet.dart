import 'package:flutter/material.dart';

showAlertDialog(
    {required BuildContext context,
    required void Function()? onPressedNo,
    required void Function()? onPressedYes,
    required Widget circleAvatarImage,
    required String cancelButtonName,
    required String actionButtonName,
    String? title,
    required String subtitle}) {
  // set up the buttons
  Widget cancelButton = TextButton(
    onPressed: onPressedNo,
    child: Text(
      cancelButtonName,
    ),
  );

  Widget continueButton = TextButton(
      onPressed: onPressedYes,
      child: Text(
        actionButtonName,
      ));

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    titlePadding: EdgeInsets.zero,
    title: Container(
      decoration: const BoxDecoration(
          color: Colors.black,
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(10), topRight: Radius.circular(10))),
      height: 180,
      child: Center(
        child: CircleAvatar(
          radius: 50,
          backgroundColor: Colors.white.withOpacity(.2),
          child: circleAvatarImage,
        ),
      ),
    ),
    content: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (title != null)
          Text(
            title,
            style:
                Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 20),
          ),
        if (title != null)
          const SizedBox(
            height: 10,
          ),
        Text(
          subtitle,
          textAlign: TextAlign.center,
          style:
              Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 15),
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Flexible(flex: 1, child: Center(child: cancelButton)),
            Container(
              height: 25,
              width: 2,
              color: Colors.grey,
            ),
            Flexible(flex: 1, child: Center(child: continueButton)),
          ],
        )
      ],
    ),
  );

  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}
