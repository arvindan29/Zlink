import 'package:flutter/material.dart';

class CustomDropDown<T> extends StatelessWidget {
  final List<DropdownMenuItem<T>>? dropdownMenuItemList;
  final ValueChanged<T?>? onChanged;
  final T? value;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final bool isEnabled;
  final double? height;
  final double? width;
  final String? hint;
  final Color borderColor;

  // final double? radius;
  final double fontSize;
  FormFieldValidator<T>? validator;

  CustomDropDown(
      {Key? key,
      this.dropdownMenuItemList,
      this.onChanged,
      this.value,
      this.isEnabled = true,
      this.hint,
      this.prefixIcon,
      this.suffixIcon,
      this.borderColor = Colors.black12,
      // this.radius = 5,
      this.height,
      this.width,
      this.validator,
      this.fontSize = 12})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      ignoring: !isEnabled,
      child: DropdownButtonFormField(
        decoration: InputDecoration(
          prefixIcon: prefixIcon,
          suffixIcon: suffixIcon,
          border: OutlineInputBorder(
            // borderRadius: BorderRadius.circular(),
            borderRadius: const BorderRadius.all(Radius.circular(30)),
            borderSide: BorderSide(color: Colors.grey[200]!, width: 2),
          ),
          enabledBorder: OutlineInputBorder(
            // borderRadius: BorderRadius.circular(radius!),
            borderSide: BorderSide(color: Colors.grey[200]!, width: 2),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: const BorderRadius.all(Radius.circular(30)),
            // borderRadius: BorderRadius.circular(radius!),
            borderSide: BorderSide(color: Colors.grey[200]!, width: 2),
          ),
          errorBorder: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(30)),
            // borderRadius: BorderRadius.circular(radius!),
            borderSide: BorderSide(color: Colors.red, width: 2),
          ),
          errorStyle: Theme.of(context)
              .textTheme
              .titleSmall
              ?.copyWith(color: Colors.red),
        ),
        items: dropdownMenuItemList,
        onChanged: onChanged,
      ),
    );
  }
}
