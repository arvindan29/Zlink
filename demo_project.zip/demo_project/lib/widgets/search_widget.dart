import 'package:demo_project/widgets/app_color.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class CustomSearchWidget extends StatelessWidget {
  final String hintText;
  final TextEditingController? controller;
  final VoidCallback? onPressed;
  final ValueChanged<String>? onChanged;
  final IconButton? suffixIcon;

  const CustomSearchWidget(
      {Key? key,
      required this.hintText,
      this.controller,
      this.onPressed,
      required this.onChanged,
      this.suffixIcon})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: defaultPadding,
      child: TextField(
        controller: controller,
        // style: bodySmallblack2E2E2EW400(context),
        decoration: InputDecoration(
          // contentPadding: defaultPadding,
          hintText: hintText,
          // hintStyle: bodySmallblack2E2E2EW400(context),
          enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: kPrimaryColor),
            borderRadius: BorderRadius.circular(defaultPadding),
          ),
          border: OutlineInputBorder(
            borderSide: const BorderSide(
              color: kPrimaryColor,
            ),
            borderRadius: BorderRadius.circular(defaultPadding),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: const BorderSide(
              color: kPrimaryColor,
            ),
            borderRadius: BorderRadius.circular(defaultPadding),
          ),
          prefixIcon: const IconButton(
            icon: Icon(Icons.search),
            onPressed: null,
          ),
          suffixIcon: suffixIcon,
        ),
        onChanged: onChanged,
      ),
    );
  }
}
