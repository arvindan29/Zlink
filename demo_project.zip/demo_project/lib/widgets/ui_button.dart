import 'package:demo_project/widgets/ui_text.dart';
import 'package:flutter/material.dart';

import 'app_color.dart';

class UButton extends StatelessWidget {
  final Function? onPressed;
  final Widget? icon;
  final String? buttonText;
  final Color buttonTextColor;
  final double buttonRadius;
  final double borderWidth;
  final Color buttonColor;
  final bool enabled;

  const UButton(
      {this.onPressed,
      this.icon,
      @required this.buttonText,
      this.buttonRadius = 12,
      this.borderWidth = 1,
      this.enabled = true,
      this.buttonColor = kPrimaryColor,
      this.buttonTextColor = kPrimaryColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ElevatedButton(
        onPressed: enabled
            ? () {
                onPressed?.call();
              }
            : null,
        style: ElevatedButton.styleFrom(
            primary: buttonColor,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(buttonRadius))),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: icon == null
              ? [
                  UText(
                    title: buttonText,
                    color: buttonTextColor,
                    weight: FONTWEIGHT.medium,
                    type: "B1",
                  ),
                ]
              : [
                  icon!,
                  UText(
                    title: buttonText,
                    color: buttonTextColor,
                    weight: FONTWEIGHT.medium,
                    type: "B1",
                  ),
                ],
        ),
      ),
    );
  }
}
