import 'package:flutter/material.dart';
import 'app_color.dart';

class UILabeledCheckbox extends StatelessWidget {
  const UILabeledCheckbox({
    super.key,
    required this.label,
    this.padding,
    this.value,
    this.onChanged,
    this.activeCheckBoxColor = ff78BC27,
  });

  final Widget label;
  final EdgeInsets? padding;
  final bool? value;
  final Function? onChanged;
  final Color activeCheckBoxColor;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        onChanged?.call(!value!);
      },
      child: Container(
        padding: padding,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              height: 32,
              width: 28,
              child: Checkbox(
                value: value,
                shape: RoundedRectangleBorder(
                    side: const BorderSide(
                        color: ffD9D9D9, width: 1, style: BorderStyle.solid),
                    borderRadius: BorderRadius.circular(4)),
                activeColor: activeCheckBoxColor,
                onChanged: (bool? newValue) {
                  onChanged?.call(newValue);
                },
              ),
            ),
            const SizedBox(width: 12),
            label,
          ],
        ),
      ),
    );
  }
}
