import 'package:flutter/material.dart';

import 'app_color.dart';

///********** START Myriad TEXT ************
/// enum for scale category
enum TYPE_TOKEN { h1, h2, h3, h4, h5, h6, d1, d2, b1, b2 }

/// enum for font weight
enum FONTWEIGHT { thin, light, bold, medium }
// enum DEVICETYPE { MOBILE, TABLET, DESKTOP }

/// MOBILE sizes
const MOBILE_TYPE_SCALE = {
  "D1": 50.0,
  "D2": 42.0,
  "h1": 36.0,
  "h2": 28.0,
  "h3": 24.0,
  "h4": 20.0,
  "h5": 16.0,
  "h6": 14.0,
  "B1": 16.0,
  "B2": 14.0,
  "CAPTION": 12.0,
  "OVERLINE": 10.0,
  "22": 22.0,
  "18": 18.0,
  "8": 8.0,
};

/// TABLET sizes
const TABLET_TYPE_SCALE = {
  "D1": 68.0,
  "D2": 48.0,
  "h1": 42.0,
  "h2": 32.0,
  "h3": 26.0,
  "h4": 22.0,
  "h5": 16.0,
  "h6": 14.0,
  "B1": 16.0,
  "B2": 14.0,
  "CAPTION": 14.0,
  "OVERLINE": 12.0,
  "22": 24.0,
  "18": 20.0,
  "8": 10.0
};

extension FONTWEIGHTEXT on FONTWEIGHT {
  FontWeight? get value {
    switch (this) {
      case FONTWEIGHT.thin:
        return FontWeight.w200;
      case FONTWEIGHT.light:
        return FontWeight.w300;
      case FONTWEIGHT.medium:
        return FontWeight.w500;
      case FONTWEIGHT.bold:
        return FontWeight.w600;
      default:
        return null;
    }
  }
}

class UText extends StatelessWidget {
  final String? title;
  final String type;
  final Color color;
  final FONTWEIGHT weight;
  final bool isOverflow;
  final bool isMaxLines;
  final TextDecoration? textDecoration;
  final TextAlign textAlign;

  UText(
      {Key? key,
      this.title,
      this.type = "B1",
      this.isOverflow = false,
      this.color = kPrimaryColor,
      this.weight = FONTWEIGHT.medium,
      this.textAlign = TextAlign.start,
      this.isMaxLines = false,
      this.textDecoration,
      controller})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      title ?? "",
      overflow: isOverflow ? TextOverflow.ellipsis : null,
      textScaleFactor: 1.0,
      textAlign: textAlign,
      maxLines: isMaxLines ? null : 3,
      style: TextStyle(
        color: color,
        fontFamily: "MyriadPro",
        fontWeight: weight.value,
        decoration: textDecoration ?? TextDecoration.none,
      ),
    );
  }
}

class TextType {
  final String? title;
  final String? type;
  final FONTWEIGHT? weight;
  final Color? color;
  final FontStyle? fontStyle;

  TextType({this.title, this.type, this.weight, this.color, this.fontStyle});
}

///********** END Myriad TEXT STYLE ************
///********** END Myriad TEXT ************
